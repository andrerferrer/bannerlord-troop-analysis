# Bannerlord — auditoria de armas e gauntlet

Repositório: andrerferrer/bannerlord-troop-analysis
PR: #105 — mesclado e verificado.
Commit de merge: e79827d9fd61834479bcbad2d7a2f2fd6f7ce26d
Head validado: f56bac82534516adf8b43e1a3d647ed5e243b4d8
CI final: 35299678281 — sucesso.

Comece por analysis/weapon_first/2026-09-17/REPORT.md e GAUNTLET.md.

Conteúdo: auditoria completa do escopo de 865 tropas de ROT no snapshot,
fontes e hashes, equipamento de foco, lacunas por arma, comparador conservador,
32 testes, fila atualizada e logs originais das rodadas de validação.

Os scripts usam fontes versionadas do repositório; este ZIP não substitui um
checkout para regeneração. Os comandos de reprodução estão no relatório.

Resultado: nenhum par de dano/velocidade por modo de ataque foi validado nas
fontes inspecionadas. Não existe ranking numérico fabricado nesta entrega.
Yi Ti Mounted Shi está ativo por escolha expressa do usuário, sem promoção da
qualidade de seus dados de arma. Os resultados empíricos anteriores não mudaram.

Testes específicos: 32/32. Descoberta integral: 432 = 429 aprovados + 3 falhas;
as mesmas 3 falhas reproduzem no commit-base sem alterações.
